// JavaScript Document

window.onload = function () {
	var id    = document.getElementsByTagName("input")[0],
		pwd   = document.getElementsByTagName("input")[1],
		login = document.getElementsByTagName("input");
	
	for(var i=2; i<5; i++){
		login[i].onclick = function(){
			if(id.value=="" || pwd.value==""){
				alert("信息没填写，检查一下！")
				return false;
			};
		}
	}
	}