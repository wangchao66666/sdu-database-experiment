create table student_info( stu_id varchar(30) not null,
  stu_pwd int(10)  ,
    stu_name varchar(20)  not null,
 stu_age int(2)  not null,
  stu_sex varchar(2) not null,
   stu_grade varchar(20),
 stu_subject varchar(20),
   stu_telephone int(80),
primary key(stu_id););

create table teacher_info( teacher_id varchar(20) not null,
  teacher_pwd varchar(20),
    teacher_name varchar(20)  not null,
   teacher_sex varchar(10),
teacher_college varchar(20),
teacher_idcard varchar(30),
primary key(teacher_id));



create table suptea
   ( s_id varchar(20) not null,
  s_pwd varchar(20),
    s_name varchar(20) not null,
   s_telephone int(10),
primary key(s_id));

create table subject_info
( subject_id int(20),
subject_name varchar(20) not null,
subject_credit varchar(20) not null,
subject_place varchar(20) not null,
primary key(subject_id)
);

create table student_subject
(subject_id int(20),
stu_id int(20),
primary key(stu_id),
foreign key(subject_id) references subject_info(subject_id)
);

create table teacher_subject
(subject_id varchar(20),
teacher_id varchar(20),
primary key(subject_id,teacher_id),
foreign key(subject_id) references subject_info(subject_id)
);

