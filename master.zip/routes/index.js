var express = require('express');
var router = express.Router();
var data=require('../database/dbConnect');
var sessionId;  //存储session值
var sessionName;


//登陆页
router.route('/')
    .get(function(req, res) {
  		res.render('login', { 
            docTitle: '学生选课管理系统' ,
            bodyTitle:'山大学生选课管理系统'
        });
	})
    .post(function(req, res) {
        var id = req.body.id_input;
        var pwd = req.body.pwd_input;
        client=data.connectServer();    //建立连接
        result=null;    //清空结果集
        if(req.body.stu_login){
           
            data.dbControl(client, "select * from student_info where stu_id='"+id+"'", function (result) {
             if(!result[0]){
                res.send('<a href="/"> 返回</a>, <script>alert("不存在这个ID！检查一下"); </script>');

            }
            else {
                if(result[0].stu_pwd==pwd){
                    req.session.stu_id=id;   //保存id到session中
                    sessionId = req.session.stu_id; //保存session在全局变量中，方便后面调用
                    req.session.stu_name=result[0].stu_name;
                    sessionName = req.session.stu_name;
                    res.redirect('/stu_index');
                }
                else{
                    res.send('<a href="/"> 返回</a>, <script>alert("密码错误！"); </script>');
                } 
            }
               
         });
        };
        if(req.body.teacher_login){
            data.dbControl(client, "select * from teacher_info where teacher_id='"+id+"'", function (result) {
            if(!result[0]){
                res.send('<a href="/"> 返回</a>, <script>alert("不存在这个ID！检查一下"); </script>');
            }
            else{
                if(result[0].teacher_pwd==pwd){
                    req.session.teacher_id=id;
                    sessionId = req.session.teacher_id;
                    req.session.teacher_name=result[0].teacher_name;
                    sessionName = req.session.teacher_name;
                    res.redirect('/teacher_index');
                }
                else{
                    res.send('<a href="/"> 返回</a>, <script>alert("密码错误！"); </script>');
                }
               }
            });
        };
               
        if(req.body.suptea_login){
            data.dbControl(client, "select * from suptea where s_id='"+id+"'", function (result) {
            if(!result[0]){
                res.send('<a href="/"> 返回</a>, <script>alert("不存在这个ID！检查一下"); </script>');
            }
            else{
                if(result[0].s_pwd==pwd){
                    req.session.s_id=id;
                    sessionId = req.session.s_id;
                    req.session.s_name=result[0].s_name;
                    sessionName = req.session.s_name;
                    res.redirect('/suptea_index');
                 }
                else{
                    res.send('<a href="/"> 返回</a>, <script>alert("密码错误！"); </script>');
                }
                }
            });
        };
        if(req.body.reg){
            res.redirect('/reg');
        }
    });


//学生个人主页
router.get('/stu_index', function(req, res) {
        if(sessionId&&sessionName){
            res.render('stu_index', { 
                docTitle: sessionName+'同学的管理空间' ,
                stuSelectedLession: '查看已选课程' ,
                stuAllLession: '查看所有课程' ,
                stuForTeacher: '查看教师信息' ,
                stuInfo: '查看个人信息'
            });
        }
    });

    //学生已选课程
    router.route('/manage/stuSelectedLession')
        .get(function(req, res) {
            if(sessionId&&sessionName){
                client=data.connectServer();
                result=null;
                data.dbControl(client, "select * from subject_info,student_subject where subject_info.subject_id=student_subject.subject_id and stu_id='"+sessionId+"'", function (result) {
                    var item = result;
                    res.render('manage/stuSelectedLession', {
                        item : item ,
                        docTitle: sessionName+'同学的管理空间' ,
                        bodyTitle: '课程' ,
                        subId: '课程号：' ,
                        subTeacher: '学科成绩：' ,
                        subDesc: '学分：' ,
                        subplace: '上课地点: '
                    })
                })
            };
        })
        .post(function(req, res) {
            var deleteSub = req.body.sub;
            var deleteStu = sessionId;
            client=data.connectServer();
            data.dbControl(client, "delete from student_subject where subject_id='"+deleteSub+"' and stu_id='"+deleteStu+"'", function (err) {
                console.log('删除了');
            })
            res.end();
        });

        //学生所有课程
        router.route('/manage/stuAllLession')
            .get(function(req, res){
                if(sessionId&&sessionName){
                client=data.connectServer();
                result=null;
                data.dbControl(client, "select * from subject_info", function (result) {
                    var item = result;
                    res.render('manage/stuAllLession', {
                        item : item ,
                        docTitle: sessionName+'同学的管理空间' ,
                        bodyTitle: '课程' ,
                        subId: '课程号：' ,
                        subTeacher: '学科老师：' ,
                        subDesc: '学分：' ,
                        subplace: '上课地点： '
                    })
                })
            };
            })
            .post(function(req, res){
                var addSub = req.body.sub;
                var addStu = sessionId;
                client=data.connectServer();
                result=null;
                data.dbControl(client, "select * from student_subject where stu_id='"+addStu+"' and subject_id='"+addSub+"'", function (result) {
                    if(result[0]){
                        res.send('选过了！');
                    }
                    else{
                        client=data.connectServer();
                        result=null;
                        data.dbControl(client, "insert into student_subject (stu_id, subject_id) values ('"+addStu+"', '"+addSub+"')", function (err) {
                            console.log('插入了！');
                        })
                    }
                    res.end();
                });
            });

        //查看任课老师
        router.get('/manage/stuForTeacher',function(req, res){
                if(sessionId&&sessionName){
                    client=data.connectServer();
                    result=null;
                    data.dbControl(client, "select * from teacher_info,subject_info,teacher_subject where teacher_info.teacher_id=teacher_subject.teacher_id and subject_info.subject_id=teacher_subject.subject_id", function(result){
                        var item = result;
                        res.render('manage/stuForTeacher', {
                            docTitle: sessionName+'同学的管理空间' ,
                            id: '姓名：' ,
                            age: '年龄：' ,
                            sex: '性别：' ,
                            tel: '电话：' ,
                            lession: '任课：' ,
                            item : item
                        })
                    })
                }
            });

        //学生个人信息
        router.route('/manage/stuInfo')
            .get(function(req, res){
                if(sessionId&&sessionName){
                    client=data.connectServer();
                    result=null;
                    data.dbControl(client, "select * from student_info where stu_id='"+sessionId+"'", function(result){
                        var item = result;
                        res.render('manage/stuInfo', {
                            docTitle: req.body.stu_name+'同学的管理空间' ,
                            item:item
                        })
                    })
                }
            })
            .post(function(req, res){
                var new_name      = req.body.stu_name,
                    new_pwd       =req.body.stu_pwd,
                    new_age       = req.body.stu_age,
                    new_sex       = req.body.stu_sex,
                    new_grade     = req.body.stu_grade,
                    new_subject   = req.body.stu_subject,
                    new_telephone = req.body.stu_telephone;
                client=data.connectServer();
                result=null;
                data.dbControl(client, "update student_info set stu_name='"+new_name+"',stu_pwd='"+new_pwd+"',stu_age='"+new_age+"', stu_sex='"+new_sex+"', stu_grade='"+new_grade+"', stu_subject='"+new_subject+"', stu_telephone='"+new_telephone+"' where stu_id='"+sessionId+"'", function(result){
                    res.render('stu_index', { 
                        docTitle: sessionName+'同学的管理空间' ,
                        stuSelectedLession: '查看已选课程' ,
                        stuAllLession: '查看所有课程' ,
                        stuForTeacher: '查看教师信息' ,
                        stuInfo: '查看个人信息'
                    });
                })
            });


//教师个人主页
router.get('/teacher_index', function(req, res) {
        if(sessionId&&sessionName){
            res.render('teacher_index', { 
                docTitle: sessionName+'老师的管理空间' ,
                teacherAllLession: '查看所有课程' ,
                teacherSelectedLession: '查看已带课程' ,
                teacherInfo: '查看个人信息',
                teacher_student: '查看学生信息'
            });
        }
    });

    //查看所有课程
    router.route('/manage/teacherAllLession')
        .get(function(req, res){
            if(sessionId&&sessionName){
                client=data.connectServer();
                result=null;
                data.dbControl(client, "select * from subject_info", function(result){
                    var item = result;
                    res.render('manage/teacherAllLession', {
                        docTitle: sessionName+'老师的管理空间' ,
                        bodyTitle: '课程' ,
                        subId: '课程号：' ,
                        subTeacher: '学科老师：' ,
                        subcredit: '学分：' ,
                        subplace: '上课地点： ',
                        item : item
                    })
                })
            }
        })
        .post(function(req, res){
            var subId=req.body.sub;
            var teacherId=sessionId;
            client=data.connectServer(); 
            result=null;
            data.dbControl(client, "select * from teacher_subject where teacher_id='"+teacherId+"' and subject_id='"+subId+"'", function (result) {
                if(result[0]){
                    res.send('已经任课了！');
                }
                else{
                    client=data.connectServer();
                    result=null;
                    data.dbControl(client, "insert into teacher_subject (subject_id,teacher_id) values ('"+subId+"','"+teacherId+"')", function (err) {
                        console.log('插入了！');
                    })
                }
                res.end();
            });
        });

        //老师已带课程
        router.route('/manage/teacherSelectedLession')
            .get(function(req, res){
                if(sessionId&&sessionName){
                    client=data.connectServer();
                    result=null;
                    data.dbControl(client, "select * from subject_info,teacher_subject where subject_info.subject_id=teacher_subject.subject_id and teacher_id='"+sessionId+"'", function(result){
                        var item = result;
                        res.render('manage/teacherSelectedLession', {
                            docTitle: sessionName+'老师的管理空间' ,
                            bodyTitle: '课程' ,
                            subId: '课程名：' ,
                            subcredit: '学分：' ,
                            subplace: '上课地点:',
                            item : item
                        })
                    })
                }
            })
            .post(function(req, res){
                var deleteSub = req.body.sub;
                var deleteTeacher = sessionId;
                client=data.connectServer();
                result=null;
                data.dbControl(client, "delete from teacher_subject where subject_id='"+deleteSub+"' and teacher_id='"+deleteTeacher+"'", function (err) {
                    console.log('删除了');
                })
                res.end();
            });
        //老师所带学生
        router.get( '/manage/teacher_student',function(req, res){
                if(sessionId&&sessionName){
                    client=data.connectServer();
                    result=null;
                    data.dbControl(client,
                        "select * from student_subject,teacher_subject,student_info,subject_info where subject_info.subject_id=student_subject.subject_id and student_subject.subject_id=teacher_subject.subject_id and student_subject.stu_id=student_info.stu_id and teacher_subject.teacher_id='"+sessionId+"'", function(result){
                        var item = result;
                        console.log(item);
                        res.render('manage/teacher_student', {
                            docTitle: sessionName+'老师的管理空间' ,
                            id: '学工号：' ,
                            age: '课程名：' ,
                            sex: '性别：' ,
                            tel: '电话：' ,
                            lession: '姓名：' ,
                            item : item
                        })
                    })
                }
            });
        //老师个人信息
        router.route('/manage/teacherInfo')
            .get(function(req, res){
                if(sessionId&&sessionName){
                    client=data.connectServer();
                    result=null;
                    data.dbControl(client, "select * from teacher_info where teacher_id='"+sessionId+"'", function(result){
                        var item = result;
                        res.render('manage/teacherInfo', {
                            docTitle: req.body.teacher_name+'教师的管理空间' ,
                            item:item
                        })
                    })
                }
            })
            .post(function(req, res){
                var new_name      = req.body.teacher_name,
                    new_pwd       =req.body.teacher_pwd,
                    new_sex       = req.body.teacher_sex,
                    new_college   = req.body.teacher_college,
                    new_idcard    = req.body.teacher_idcard;
                client=data.connectServer();
                result=null;
                data.dbControl(client, "update teacher_info set teacher_name='"+new_name+"',teacher_pwd='"+new_pwd+"', teacher_sex='"+new_sex+"', teacher_college='"+new_college+"', teacher_idcard='"+new_idcard+"' where teacher_id='"+sessionId+"'", function(result){
                    res.render('teacher_index', { 
                    docTitle: sessionName+'老师的管理空间' ,
                    teacherAllLession: '查看所有课程' ,
                    teacherSelectedLession: '查看已带课程' ,
                    teacherInfo: '查看个人信息',
                    teacher_student: '查看学生信息'
                });
                })
            });

//管理员
    router.get('/suptea_index', function(req, res) {
        if(sessionId&&sessionName){
            res.render('suptea_index', { 
            docTitle: sessionName+'管理员的管理空间' ,
            suptea_teacher: '查看及修改老师信息' ,
            suptea_class: '查看及修改课程信息' ,
            suptea_student: '查看及修改学生信息' ,
            suptea_Info: '查看及修改个人信息',
            suptea_insertclass:'增加课程',
            suptea_insertteacher: '增加老师'
           });
        }
    });
 //查看老师
   router.route('/manage/suptea_teacher')
    .get(function(req, res){
     if(sessionId&&sessionName){ 
         client=data.connectServer();
         result=null;
         data.dbControl(client, "select * from teacher_info", function(result){
             var item = result;console.log(req.body);
             res.render('manage/suptea_teacher', {
                 docTitle: sessionName+'管理员的管理空间' , 
                 bodyTitle: '老师' ,
                 subId: '学工号：' ,
                 subTeacher: '姓名：' ,
                 sub_pwd:'密码: ' ,
                 sub_sex: '性别：' ,
                 subteacher_college: '学院：',
                 subteacher_idcard: '身份证号:' ,
                 item : item 
             }) 
         })
     }
   })
   .post(function(req, res){
    var new_id        = req.body.teacher_id,
        new_name      = req.body.teacher_name,
        new_pwd       = req.body.teacher_pwd,
        new_college   = req.body.teacher_college,
        new_idcard    = req.body.teacher_idcard;
    client=data.connectServer();
    result=null;console.log(new_id);
    data.dbControl(client, "update teacher_info set teacher_pwd='"+new_pwd+"',teacher_college='"+new_college+"', teacher_idcard='"+new_idcard+"'where teacher_id='"+new_id+"' ", function (err) {
        res.render('suptea_index', { 
            docTitle: sessionName+'管理员的管理空间' ,
            suptea_teacher: '查看及修改老师信息' ,
            suptea_class: '查看及修改课程信息' ,
            suptea_student: '查看及修改学生信息' ,
            suptea_Info: '查看及修改个人信息',
            suptea_insertclass:'增加课程',
            suptea_insertteacher: '增加老师'
           });
       })
    //res.end();
   });
//查看学生
 router.route('/manage/suptea_student')
 .get(function(req, res){
  if(sessionId&&sessionName){ 
      client=data.connectServer();
      result=null;
      data.dbControl(client, "select * from student_info", function(result){
          var item = result;
          res.render('manage/suptea_student', {
              docTitle: sessionName+'管理员的管理空间' , 
              bodyTitle: '学生' ,
              subId: '学工号：' ,
              substudent: '姓名：' ,
              sub_pwd : '密码: ',
              sub_sex: '性别：',
              sub_college:'学院：',
              item : item 
          }) 
      })
  }
})
.post(function(req, res){
    var new_id        = req.body.stu_id,
        new_name      = req.body.stu_name,
        new_pwd       = req.body.stu_pwd,
        new_sex       = req.body.stu_sex,
        new_college   = req.body.stu_subject;
    client=data.connectServer();
    result=null;
    data.dbControl(client, "update student_info set stu_name='"+new_name+"',stu_pwd='"+new_pwd+"', stu_sex='"+new_sex+"',stu_subject='"+new_college+"' where stu_id='"+new_id+"'", function (err) {
        res.render('suptea_index', { 
            docTitle: sessionName+'管理员的管理空间' ,
            suptea_teacher: '查看及修改老师信息' ,
            suptea_class: '查看及修改课程信息' ,
            suptea_student: '查看及修改学生信息' ,
            suptea_Info: '查看及修改个人信息',
            suptea_insertclass:'增加课程',
            suptea_insertteacher: '增加老师'
           })
       })
    //res.end();
   });
 //查看课程
router.route('/manage/suptea_class')
.get(function(req, res){
 if(sessionId&&sessionName){ 
     client=data.connectServer();
     result=null;
     data.dbControl(client, "select * from subject_info", function(result){
         var item = result;
         res.render('manage/suptea_class', {
             docTitle: sessionName+'管理员的管理空间' , 
             bodyTitle: '课程' ,
             subId: '课程号：' ,
             subname: '课程名：' ,
             sub_credit: '学分：',
             sub_place:'地点：',
             item : item 
         }) 
     })
 }
})
.post(function(req, res){
    var new_id        = req.body.subject_id,
        new_name      = req.body.subject_name,
        new_credit    = req.body.subject_credit,
        new_place     = req.body.subject_place;
    client=data.connectServer();
    result=null;
    data.dbControl(client, "update subject_info set subject_name='"+new_name+"',subject_credit='"+new_credit+"', subject_place='"+new_place+"'where subject_id='"+new_id+"'", function (err) {
        res.render('suptea_index', { 
            docTitle: sessionName+'管理员的管理空间' ,
            suptea_teacher: '查看及修改老师信息' ,
            suptea_class: '查看及修改课程信息' ,
            suptea_student: '查看及修改学生信息' ,
            suptea_Info: '查看及修改个人信息',
            suptea_insertclass:'增加课程',
            suptea_insertteacher: '增加老师'
           })
       })
    //res.end();
   });  
//增加课程
   router.route('/manage/suptea_insertclass')
   .get(function(req, res){
    var item = result;
    res.render('manage/suptea_insertclass', {
        docTitle: '增加选课' 
     })
   })
   .post(function(req, res){
       var new_id      = req.body.subject_id,
           new_name    = req.body.subject_name,
           new_credit  = req.body.subject_credit,
           new_place   = req.body.subject_place ,
       client=data.connectServer();
       result=null;console.log(req.body);
       if(req.body.subject_id!=''&&req.body.subject_name!='')
       {
           data.dbControl(client, "insert into subject_info (subject_id,subject_name,subject_credit,subject_place) values ('"+new_id+"',  '"+new_name+"', '"+new_credit+"','"+new_place+"')", function(result){
           sessionId = new_id;
           sessionName = new_name;
           res.redirect('/suptea_index');
          })
       }
       else{
        res.send('<a href="/manage/suptea_insertclass"> 返回</a>, <script>alert("请填写完整信息！"); </script>');
       }
   });
   //增加老师
   router.route('/manage/suptea_insertteacher')
   .get(function(req, res){
    var item = result;
    res.render('manage/suptea_insertteacher', {
        docTitle: '增加老师' 
     })
   })
   .post(function(req, res){
       var new_id      = req.body.teacher_id,
           new_pwd     = req.body.teacher_pwd,
           new_name    = req.body.teacher_name,
           new_sex     = req.body.teacher_sex,
           new_college = req.body.teacher_college,
           new_idcard   = req.body.teacher_idcard ,
       client=data.connectServer();
       result=null;
       if(req.body.teacher_id!=''&&req.body.teacher_name!='')
       {
          data.dbControl(client, "insert into teacher_info (teacher_id,teacher_pwd,teacher_name,teacher_sex,teacher_college,teacher_idcard) values ('"+new_id+"', '"+new_pwd+"', '"+new_name+"', '"+new_sex+"', '"+new_college+"', '"+new_idcard+"')", function(result){
          sessionId = new_id;
          sessionName = new_name;
          res.redirect('/suptea_index');
         })
       }
       else{
        res.send('<a href="/manage/suptea_insertteacher"> 返回</a>, <script>alert("请填写完整信息！"); </script>');
       }
    //    res.end();
   });
   //查看个人信息
   router.route('/manage/suptea_Info')
   .get(function(req, res){
       if(sessionId&&sessionName){
           client=data.connectServer();
           result=null;
           console.log("111");
           data.dbControl(client, "select * from suptea where s_id='"+sessionId+"'", function(result){
               console.log(result);
                var item = result;
                res.render('manage/suptea_Info', {
                   docTitle: req.body.s_name+'管理员的管理空间' ,
                   item:item
               })
           })
       }
   })
   .post(function(req, res){
       var new_name      =req.body.s_name,
           new_pwd       =req.body.s_pwd,
           new_telephone =req.body.s_telephone;
       client=data.connectServer();
       result=null;
       data.dbControl(client, "update suptea set s_name='"+new_name+"',s_pwd='"+new_pwd+"',s_telephone='"+new_telephone+"' where s_id='"+sessionId+"'", function(result){
        res.render('suptea_index', { 
            docTitle: sessionName+'管理员的管理空间' ,
            suptea_teacher: '查看及修改老师信息' ,
            suptea_class: '查看及修改课程信息' ,
            suptea_student: '查看及修改学生信息' ,
            suptea_Info: '查看及修改个人信息',
            suptea_insertclass:'增加课程',
            suptea_insertteacher: '增加老师'
           })
       })
   });
//注册页
router.route('/reg')
    .get(function(req, res){
        var item = result;
        res.render('reg', {
            docTitle: '注册学习开始' 
        })
    })
    .post(function(req, res){
        var new_id        = req.body.stu_id,
            new_pwd       = req.body.stu_pwd,
            new_name      = req.body.stu_name,
            new_age       = req.body.stu_age,
            new_sex       = req.body.stu_sex,
            new_grade     = req.body.stu_grade,
            new_subject   = req.body.stu_subject,
            new_telephone = req.body.stu_telephone;
        client=data.connectServer();
        result=null;
        data.dbControl(client, "insert into student_info (stu_id, stu_pwd, stu_name, stu_age, stu_sex, stu_grade, stu_subject, stu_telephone) values ('"+new_id+"', '"+new_pwd+"', '"+new_name+"', '"+new_age+"', '"+new_sex+"', '"+new_grade+"', '"+new_subject+"', '"+new_telephone+"')", function(result){
            sessionId = new_id;
            sessionName = new_name;
            res.redirect('/');
        })
    });
//寻找老师
    router.route('/select')
    .post(function(req,res)
    {
        var name=req.body.teacher_name;console.log(req.body);
        if(name){ 
            client=data.connectServer();
            result=null;
            data.dbControl(client, "select * from teacher_info where teacher_name  ='"+name+"' ", function(result){
                var item = result;
                
                res.render('manage/suptea_teacher', {
                    docTitle: sessionName+'管理员的管理空间' , 
                    bodyTitle: '老师' ,
                    subId: '学工号：' ,
                    subTeacher: '姓名：' ,
                    sub_pwd:'密码: ' ,
                    sub_sex: '性别：' ,
                    subteacher_college: '学院：',
                    subteacher_idcard: '身份证号:' ,
                    item : item 
                }) 
            })
        }
        else{
            client=data.connectServer();
            result=null;
            data.dbControl(client, "select * from teacher_info ", function(result){
                var item = result;
                res.render('manage/suptea_teacher', {
                    docTitle: sessionName+'管理员的管理空间' , 
                    bodyTitle: '老师' ,
                    subId: '学工号：' ,
                    subTeacher: '姓名：' ,
                    sub_pwd:'密码: ' ,
                    sub_sex: '性别：' ,
                    subteacher_college: '学院：',
                    subteacher_idcard: '身份证号:' ,
                    item : item 
                }) 
            })
        }
        
    })
//寻找学生     
    router.route('/select_stu')
    .post(function(req,res)
    {
        var name=req.body.student_name;console.log(req.body);
        if(name){ 
            client=data.connectServer();
            result=null;
            data.dbControl(client, "select * from student_info where stu_name  ='"+name+"' ", function(result){
                    var item = result;
                    res.render('manage/suptea_student', {
                        docTitle: sessionName+'管理员的管理空间' , 
                        bodyTitle: '学生' ,
                        subId: '学工号：' ,
                        substudent: '姓名：' ,
                        sub_pwd : '密码 ',
                        sub_sex: '性别：',
                        sub_college:'学院：',
                        item : item 
                    }) 
                })
        }
        else{
            client=data.connectServer();
            result=null;
            data.dbControl(client, "select * from student_info ", function(result){
                var item = result;
                    res.render('manage/suptea_student', {
                        docTitle: sessionName+'管理员的管理空间' , 
                        bodyTitle: '学生' ,
                        subId: '学工号：' ,
                        substudent: '姓名：' ,
                        sub_pwd : '密码 ',
                        sub_sex: '性别：',
                        sub_college:'学院：',
                        item : item 
                   })
            })
        }
        
    })
//寻找课程
    router.route('/select_class')
    .post(function(req,res)
    {
        var name=req.body.class_name;console.log(req.body);
        if(name){ 
            client=data.connectServer();
            result=null;
            data.dbControl(client, "select * from subject_info where subject_name  ='"+name+"' ", function(result){
                var item = result;
                res.render('manage/suptea_class', {
                docTitle: sessionName+'管理员的管理空间' , 
                bodyTitle: '课程' ,
                subId: '课程号：' ,
                subname: '课程名：' ,
                sub_credit: '学分：',
                sub_place:'地点：',
                item : item 
                }) 
            })

        }
        else{
            client=data.connectServer();
            result=null;
            data.dbControl(client, "select * from subject_info ", function(result){
                var item = result;
                res.render('manage/suptea_class', {
                    docTitle: sessionName+'管理员的管理空间' , 
                    bodyTitle: '课程' ,
                    subId: '课程号：' ,
                    subname: '课程名：' ,
                    sub_credit: '学分：',
                    sub_place:'地点：',
                    item : item 
                }) 
            })
        }
    })

//删除课程
    router.route('/delete_class')
    .post(function(req, res)
    {
        var subId=req.body.subject_id;
        console.log(req.body);
        if(subId)
        {
            client=data.connectServer(); 
            result=null;
            data.dbControl(client, "select * from subject_info where subject_id='"+subId+"'", function (result) {
            if(result[0]){
                client=data.connectServer();
                result=null;
                data.dbControl(client, "delete from subject_info where subject_id='"+subId+"'", function (err) {
                    console.log('删除了！');
                    client=data.connectServer();
                    result=null;
                    data.dbControl(client, "select * from subject_info ", function(result){
                    var item = result;
                    res.render('manage/suptea_class', {
                       docTitle: sessionName+'管理员的管理空间' , 
                       bodyTitle: '课程' ,
                       subId: '课程号：' ,
                       subname: '课程名：' ,
                       sub_credit: '学分：',
                       sub_place:'地点：',
                       item : item 
                    }) 
                })    
              }) 
            }
            else{
                res.send('<a href="/manage/suptea_class"> 返回</a>, <script>alert("不存在这门课！检查一下"); </script>');
            }
           })
        }
        else{
            client=data.connectServer();
            result=null;
            data.dbControl(client, "select * from subject_info ", function(result){
                var item = result;
                res.render('manage/suptea_class', {
                    docTitle: sessionName+'管理员的管理空间' , 
                    bodyTitle: '课程' ,
                    subId: '课程号：' ,
                    subname: '课程名：' ,
                    sub_credit: '学分：',
                    sub_place:'地点：',
                    item : item 
                }) 
            })
        }
    });
//删除学生
    router.route('/delete_student')
    .post(function(req, res)
    {
        var subId=req.body.stu_name;
        console.log(req.body);
        if(subId)
        {
            client=data.connectServer(); 
            result=null;
            data.dbControl(client, "select * from student_info where stu_name='"+subId+"'", function (result) {
            if(result[0]){
                client=data.connectServer();
                result=null;
                data.dbControl(client, "delete from student_info where stu_name='"+subId+"'", function (err) {
                    console.log('删除了！');
                    client=data.connectServer();
                    result=null;
                    data.dbControl(client, "select * from student_info", function(result){
                    var item = result;
                    console.log(item);
                    res.render('manage/suptea_student', {
                        docTitle: sessionName+'管理员的管理空间' , 
                        bodyTitle: '学生' ,
                        subId: '学工号：' ,
                        substudent: '姓名：' ,
                        sub_pwd : '密码 ',
                        sub_sex: '性别：',
                        sub_college:'学院：',
                        item : item 
                   }) 
              })        
            })
            }
            else{
                res.send('<a href="/manage/suptea_student"> 返回</a>, <script>alert("不存在这门课！检查一下"); </script>');
            }
           })
        }
        else{
            client=data.connectServer();
            result=null;
            data.dbControl(client, "select * from student_info ", function(result){
                var item = result;
                res.render('manage/suptea_student', {
                    docTitle: sessionName+'管理员的管理空间' , 
                    bodyTitle: '学生' ,
                    subId: '学工号：' ,
                    substudent: '姓名：' ,
                    sub_pwd : '密码 ',
                    sub_sex: '性别：',
                    sub_college:'学院：',
                    item : item 
               }) 
            })
        }
    });
//删除教师
    router.route('/delete_teacher')
    .post(function(req, res)
    {
        var subId=req.body.teacher_name;
        if(subId)
        {
            client=data.connectServer(); 
            result=null;
            data.dbControl(client, "select * from teacher_info where teacher_name='"+subId+"'", function (result) {
            if(result[0])
            {
                client=data.connectServer();
                result=null;
                data.dbControl(client, "delete from teacher_info where teacher_name='"+subId+"'", function (err) {
                    console.log('删除了！');
                    client=data.connectServer();
                    result=null;
                    data.dbControl(client, "select * from teacher_info", function(result){
                    var item = result;
                    res.render('manage/suptea_teacher', {
                        docTitle: sessionName+'管理员的管理空间' , 
                        bodyTitle: '老师' ,
                        subId: '学工号：' ,
                        subTeacher: '姓名：' ,
                        sub_pwd:'密码: ' ,
                        sub_sex: '性别：' ,
                        subteacher_college: '学院：',
                        subteacher_idcard: '身份证号:' ,
                        item : item 
                    })  
              })        
            })
            }
            else{
                res.send('<a href="/manage/suptea_teacher"> 返回</a>, <script>alert("不存在这门课！检查一下"); </script>');
            }
           })
        }
        else
        {
            client=data.connectServer();
            result=null;
            data.dbControl(client, "select * from teacher_info ", function(result){
                var item = result;
                res.render('manage/suptea_teacher', {
                    docTitle: sessionName+'管理员的管理空间' , 
                    bodyTitle: '老师' ,
                    subId: '学工号：' ,
                    subTeacher: '姓名：' ,
                    sub_pwd:'密码: ' ,
                    sub_sex: '性别：' ,
                    subteacher_college: '学院：',
                    subteacher_idcard: '身份证号:' ,
                    item : item 
                }) 
            })
        }
    });

module.exports = router;